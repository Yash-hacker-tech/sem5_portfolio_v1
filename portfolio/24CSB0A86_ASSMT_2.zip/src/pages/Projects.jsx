import projects from '../data/projects';
import ProjectCard from '../components/ProjectCard';


// Prop drilling demo:
//   Projects (this page)  →  ProjectCard  →  TechBadge
// Each project object is destructured and passed as individual props to ProjectCard.
// ProjectCard passes each tech string as a prop to TechBadge.

function Projects() {
  return (
    <main className="projects-page page-enter">
      <section className="section" aria-labelledby="projects-heading">
        <div className="container">
          <h1 className="section-title" id="projects-heading">Projects</h1>
          <p className="section-subtitle">
            Things I've built — from hackathon nights to semester projects.
          </p>

          <div className="projects-grid">
            {projects.map(project => (
              // Passing each field from the project object as individual props to ProjectCard.
              // No hardcoded content inside ProjectCard — all data flows through props.
              <ProjectCard
                key={project.id}
                id={project.id}
                title={project.title}
                description={project.description}
                techStack={project.techStack}
                link={project.link}
              />
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

export default Projects;
