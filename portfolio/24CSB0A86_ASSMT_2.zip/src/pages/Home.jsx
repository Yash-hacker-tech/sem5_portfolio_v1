import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';


function LoadingSpinner() {
  return (
    <div className="home-loading" role="status" aria-label="Loading portfolio">
      <div className="home-loading__spinner" aria-hidden="true" />
      <p>Loading…</p>
    </div>
  );
}

function Home() {
  // useEffect #1: loading sequence on component mount (empty dependency array [])
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setReady(true), 1000);
    // Cleanup: clear timeout if component unmounts before it fires
    return () => clearTimeout(timer);
  }, []); // runs once on mount

  if (!ready) return <LoadingSpinner />;

  return (
    <main className="home page-enter">
      {/* Hero */}
      <section className="hero section" aria-labelledby="hero-heading">
        <div className="container hero__inner">
          <div className="hero__text">
            <p className="hero__eyebrow">Hi, I'm</p>
            <h1 className="hero__name" id="hero-heading">Yash</h1>
            <p className="hero__tagline">
              Full Stack Developer · AI/ML Enthusiast · Competitive Programmer
            </p>
            <p className="hero__bio">
              B.Tech CSE student at NIT Warangal ('28), building things at the intersection of
              clean code and useful products. I like designing systems that are fast, maintainable,
              and actually solve the problem.
            </p>
            <div className="hero__actions">
              <Link to="/projects" className="btn btn-primary">View projects</Link>
              <Link to="/contact" className="btn btn-outline">Get in touch</Link>
            </div>
          </div>

          <div className="hero__card" aria-hidden="true">
            <div className="hero__avatar">Y</div>
            <div className="hero__meta">
              <span className="hero__meta-item">📍 NIT Warangal</span>
              <span className="hero__meta-item">🎓 CSE '28</span>
              <span className="hero__meta-item">💻 Open to internships</span>
            </div>
          </div>
        </div>
      </section>

      {/* Quick stats */}
      <section className="stats-strip" aria-label="Quick statistics">
        <div className="container stats-strip__grid">
          {[
            { value: '4+', label: 'Projects built' },
            { value: '400+', label: 'Problems solved' },
            { value: '3', label: 'Hackathons' },
            { value: '1372', label: 'Codeforces rating' },
          ].map(({ value, label }) => (
            <div key={label} className="stat">
              <span className="stat__value">{value}</span>
              <span className="stat__label">{label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* CTA strip */}
      <section className="home-cta section" aria-label="Call to action">
        <div className="container home-cta__inner">
          <h2>Want to collaborate or hire?</h2>
          <p>I'm actively looking for summer internship opportunities in SDE / ML roles.</p>
          <Link to="/contact" className="btn btn-primary">Let's talk →</Link>
        </div>
      </section>
    </main>
  );
}

export default Home;
