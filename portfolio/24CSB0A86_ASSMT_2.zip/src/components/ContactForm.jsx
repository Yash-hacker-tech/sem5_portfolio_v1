import { useState } from 'react';


const INITIAL = { name: '', email: '', subject: '', message: '' };
const INITIAL_ERRORS = { name: '', email: '', message: '' };

function validate(fields) {
  const errors = { ...INITIAL_ERRORS };
  if (!fields.name.trim()) errors.name = 'Name is required.';
  if (!fields.email.trim()) {
    errors.email = 'Email is required.';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email)) {
    errors.email = 'Enter a valid email address.';
  }
  if (fields.message.trim().length < 10)
    errors.message = 'Message must be at least 10 characters.';
  return errors;
}

function hasErrors(errors) {
  return Object.values(errors).some(Boolean);
}

function ContactForm() {
  const [fields, setFields] = useState(INITIAL);          // controlled inputs
  const [errors, setErrors] = useState(INITIAL_ERRORS);   // validation errors
  const [touched, setTouched] = useState({});             // which fields user visited
  const [submitted, setSubmitted] = useState(false);       // success state

  const handleChange = e => {
    const { name, value } = e.target;
    const next = { ...fields, [name]: value };
    setFields(next);
    // Re-validate on change only for touched fields
    if (touched[name]) {
      setErrors(validate(next));
    }
  };

  const handleBlur = e => {
    const { name } = e.target;
    setTouched(t => ({ ...t, [name]: true }));
    setErrors(validate(fields));
  };

  const currentErrors = validate(fields);
  const isDisabled = hasErrors(currentErrors);

  const handleSubmit = e => {
    e.preventDefault();
    setTouched({ name: true, email: true, message: true });
    const errs = validate(fields);
    setErrors(errs);
    if (hasErrors(errs)) return;
    setSubmitted(true);
  };

  const handleReset = () => {
    setFields(INITIAL);
    setErrors(INITIAL_ERRORS);
    setTouched({});
    setSubmitted(false);
  };

  if (submitted) {
    return (
      <div className="contact-success" role="status">
        <div className="contact-success__icon" aria-hidden="true">✓</div>
        <h3>Message sent!</h3>
        <p>Thanks for reaching out. I'll get back to you soon.</p>
        <button className="btn btn-outline" onClick={handleReset}>Send another</button>
      </div>
    );
  }

  return (
    <form className="contact-form" onSubmit={handleSubmit} noValidate aria-label="Contact form">
      <div className="form-row">
        <div className={`form-group${touched.name && errors.name ? ' form-group--error' : ''}`}>
          <label htmlFor="cf-name" className="form-label">Name <span aria-hidden="true">*</span></label>
          <input
            id="cf-name"
            name="name"
            type="text"
            className="form-input"
            value={fields.name}
            onChange={handleChange}
            onBlur={handleBlur}
            placeholder="Your full name"
            aria-required="true"
            aria-describedby={touched.name && errors.name ? 'err-name' : undefined}
            aria-invalid={!!(touched.name && errors.name)}
          />
          {touched.name && errors.name && (
            <span id="err-name" className="form-error" role="alert">{errors.name}</span>
          )}
        </div>

        <div className={`form-group${touched.email && errors.email ? ' form-group--error' : ''}`}>
          <label htmlFor="cf-email" className="form-label">Email <span aria-hidden="true">*</span></label>
          <input
            id="cf-email"
            name="email"
            type="email"
            className="form-input"
            value={fields.email}
            onChange={handleChange}
            onBlur={handleBlur}
            placeholder="you@example.com"
            aria-required="true"
            aria-describedby={touched.email && errors.email ? 'err-email' : undefined}
            aria-invalid={!!(touched.email && errors.email)}
          />
          {touched.email && errors.email && (
            <span id="err-email" className="form-error" role="alert">{errors.email}</span>
          )}
        </div>
      </div>

      <div className="form-group">
        <label htmlFor="cf-subject" className="form-label">Subject</label>
        <input
          id="cf-subject"
          name="subject"
          type="text"
          className="form-input"
          value={fields.subject}
          onChange={handleChange}
          placeholder="What's this about?"
        />
      </div>

      <div className={`form-group${touched.message && errors.message ? ' form-group--error' : ''}`}>
        <label htmlFor="cf-message" className="form-label">Message <span aria-hidden="true">*</span></label>
        <textarea
          id="cf-message"
          name="message"
          className="form-input form-textarea"
          value={fields.message}
          onChange={handleChange}
          onBlur={handleBlur}
          placeholder="Tell me what's on your mind…"
          rows={5}
          aria-required="true"
          aria-describedby={touched.message && errors.message ? 'err-message' : undefined}
          aria-invalid={!!(touched.message && errors.message)}
        />
        {touched.message && errors.message && (
          <span id="err-message" className="form-error" role="alert">{errors.message}</span>
        )}
        <span className="form-hint">{fields.message.length} / 10 chars minimum</span>
      </div>

      <button
        type="submit"
        className="btn btn-primary contact-form__submit"
        disabled={isDisabled && Object.keys(touched).length > 0}
        aria-disabled={isDisabled && Object.keys(touched).length > 0}
      >
        Send message
      </button>
    </form>
  );
}

export default ContactForm;
